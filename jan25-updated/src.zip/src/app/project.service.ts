import { Injectable } from '@angular/core';
import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
  import { from } from 'rxjs';
import { stringify } from 'querystring';
import Order from './Order.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectService implements CanActivate {

//  url = "http://192.168.43.71:8084/project";

  constructor(private router:Router,
              private http:HttpClient) { }

  url = "http://localhost:8084/project";

  usr:any={};
  welcomeMessage;
  
//LOGIN HANDLER
  ValidateUser(user:any){
    return this.http.post(this.url+"/user/validate", user);
  }
  GetPassword(username:any){
    return this.http.post(this.url+"/user/getPassword", username);
  }
  ChangePassword(user:any){
    console.log("project.service.ts, :"+user.password);
    return this.http.post(this.url+"/user/changePassword", user);
  }
  GetVendorRegNo(username){
    return this.http.post(this.url+"/user/getPassword",username);
  }
  GerAllVendors(){
    return this.http.get(this.url+"/user/getAllVendors");
  }

  canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot){
    if(this.IsLoggedIn()) 
      return true;
    else  
      this.router.navigate(['/login']); 
    return false;    
  }

  IsLoggedIn(){
    if(window.sessionStorage.getItem("isActive") != null && window.sessionStorage.getItem("isActive") == "1")
      return true;
    return false;
  }

  async Register(user:any){
    return this.http.post(this.url+"/user/register", user);
  }



//PRODUCT SERVICE HANDLERS    
  GetAllProducts(){
    return this.http.get(this.url+"/product")
  }
  SaveOrUpdateProduct(product, vId){
      return this.http.post(this.url+"/product/addProduct/"+vId, product)
    }

  

  
  SaveOrUpdateProduct1(product, image:File){
  //  console.log("ProjectService.SaveOrUpdateProduct()"+formData.image.size)
 /*   console.log("SaveOrUpdateProduct: "+formData.gtin)
    let gtin = formData.gtin;
    let name = formData.name;
    let category = formData.category;
    let material = formData.material;
    let shape = formData.shape;
    let finish = formData.finish;
    let image = formData.image;
    let description = formData.description;
    let price = formData.price;
    let product={
      gtin:"00007777",
      name:"nobita",
      category:"PORCELAIN",
      material:"CLAY",
      shape:"MASAIC",
      finish:"GLAZED",
      image:File=null,
      description:"this is porcelain tile made from clay",
      price:899
    };
    */
   console.log("image name: "+image.name+" size: "+image.size)
   console.log("product.image: "+product.image)
   let imageForm = new FormData()
   imageForm.append('image', image)
   imageForm.append('product',JSON.parse(JSON.stringify( product)))

//    let headers = new Headers();
//    headers.append('Accept', 'application/json');
//    headers.append("Content-Type", 'multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW');

// let headers = new Headers();
// headers.append('Accept', 'application/json');
// headers.append("Content-Type", 'multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW');
// return this.http.post(this.url+'/product/addProduct',imageForm,{headers: headers})

 //  return this.http.post(this.url+"/product/addProduct", imageForm)//, {headers: headers}); 
   //, category, material, shape, finish, image, description, price);
 //  return this.http.post(this.url+"/product/addProduct", imageForm, {headers:Headers})//, {headers: headers});

  }

  GetProductById(productId){
    return this.http.get(this.url+"/product/"+productId);
  }
  DeleteProductById(productId){
    return this.http.post(this.url+"/product/deleteProductById", productId);
  }

//CART/ORDER HANDLER
  CheckOut(order:Order, cId){
    console.log("projectService.CheckOut called...")
    return this.http.post(this.url+"/order/addOrder/"+cId, order);
  }
  GetAllOrders(userId:any){
    return this.http.get(this.url+"/order/get/"+userId);
  }


//LOGOUT HANDLER    
  Logout(){
    localStorage.removeItem("username");
    localStorage.removeItem("role");
    localStorage.removeItem("isActive");
    localStorage.removeItem("user id");
    localStorage.removeItem("products")
    this.router.navigate(['/login']);
  } 
}
