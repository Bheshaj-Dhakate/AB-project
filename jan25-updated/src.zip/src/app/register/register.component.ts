import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../project.service';
import { Router} from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  usr:any; 
  message;

  constructor(private projectService:ProjectService, private router:Router) { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
/*     setTimeout(() => {
      this.router.navigate)(['/home']);
    }, 2000); */
  }
  
  async Register(formdata)
  {
    let user = formdata.form.value;
//    window.alert("user.role : "+user.role)
    if(this.role =='VENDOR'){
      window.alert("user.role"+user.role)
      this.router.navigate(['/registorvendor'])
    }else{  
    if(user.name != undefined && user.email != undefined && user.password != undefined 
      && user.address != undefined && user.mobileNo != undefined && user.role != undefined ){
        console.log("Register.Component.ts, user = "+user.mobileNo);
          console.log("CUSTOMER");
          let observableResult = await this.projectService.Register(user);
          console.log(observableResult);
          observableResult.subscribe((result : any)=>{
              if(result !== undefined)
                window.alert("User registered successfully!");
              else
              window.alert("User registration failed!"); 
          });
    }else
        window.alert("Missing field...")
   // this.router.navigate(['/register'])
  }
  this.router.navigate(['/login'])
  }

  GoToHome(){
    this.router.navigate(['/home']);
  }
}
