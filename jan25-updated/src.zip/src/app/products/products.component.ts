import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;

  constructor(private router:Router) { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
    this.router.navigate(['/home'])
  }

  SetActionADD(){
    localStorage.setItem("action","ADD");
    this.router.navigate(['/addproduct']);
  }
  SetActionEDIT(){
    localStorage.setItem("action","EDIT");
    this.router.navigate(['/addproduct']);
  }
}
