import Product from './Product.model';

export default class OrderProduct{

    public id:number;
    public product_id:Product;
    public quantity:number;
    constructor(){} 
}