import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  name;
  email;
  contactNumber;

  constructor(private router:Router) { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
  }

  Contact(){
    if(this.name != undefined && this.email != undefined && this.contactNumber != undefined){
      window.alert("Thank you for contacting us...we will get in touch with you shortly...")
      this.router.navigate(['/home'])
    }
    else{
      window.alert("Please enter your details..")
      this.router.navigate(['/contactus'])
    }

  }

}
