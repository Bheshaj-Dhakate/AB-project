package com.project.pojos;

public enum ProductSeries {
	CARVING, DECOR, WOOD, GLOSSY, MATT, METAL, POLISHED
}
