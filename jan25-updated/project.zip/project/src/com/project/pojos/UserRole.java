package com.project.pojos;

public enum UserRole {
	CUSTOMER, ADMIN, VENDOR, OWNER
}
