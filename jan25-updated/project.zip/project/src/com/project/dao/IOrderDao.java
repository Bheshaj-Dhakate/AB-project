package com.project.dao;

import java.util.List;

import com.project.pojos.Order;

public interface IOrderDao {
	List<Order> getAllOrders(String userName);
	List<Order> getOrderById(int userId);
	Boolean saveOrUpdateOrder(Order o, int cId);
	Boolean deleteOrder(int orderId);
}
