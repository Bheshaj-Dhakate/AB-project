package com.project.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.pojos.User;

@Repository
@Transactional
public class UserDaoImpl implements IUserDao 
{
	@Autowired
	private SessionFactory sf;

	@Override
	public User validateUser(User u) 
	{
		String jpql = "select u from User u left outer join fetch u.orders o where u.email = :em and u.password = :pswd";
		User u1 = sf.getCurrentSession().createQuery(jpql, User.class)
				.setParameter("em", u.getEmail())
				.setParameter("pswd", u.getPassword())
				.getSingleResult();
		jpql = "select u from User u left outer join fetch u.products p where u.email = :em and u.password = :pswd";
		u1 = sf.getCurrentSession().createQuery(jpql, User.class)
				.setParameter("em", u.getEmail())
				.setParameter("pswd", u.getPassword())
				.getSingleResult();
		 return u1;
	}

	@Override
	public Boolean registerUser(User u) {
		System.out.println("UserDaoImpl.registerUser :"+u);
		try {
			sf.getCurrentSession().merge(u);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return false;
		
	}

	@Override
	public User getPassword(String username) {
		String jpql = "select u from User u where u.email=:username";
		try {
			return sf.getCurrentSession().createQuery(jpql, User.class)
					.setParameter("username", username).getSingleResult();
		}catch(RuntimeException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Boolean changePassword(User u) {
		try {
			String jpql = "select u from User u where u.email=:email";
			User uOld = sf.getCurrentSession().createQuery(jpql, User.class)
					.setParameter("email", u.getEmail()).getSingleResult();
			uOld.setPassword(u.getPassword());
			
			sf.getCurrentSession().update(uOld);
				return true;
		}catch(RuntimeException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public User getUserById(int uId) {
		try {
			String jpql = "select u from User u left outer join fetch u.products p where u.id=:id";
			User u = sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", uId).getSingleResult();
			return u;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<User> getAllVendors() {
		try {
			String jpql = "select u from User u where u.role='VENDOR'";
			return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}	
	
}
