package com.project.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.project.pojos.Product;
import com.project.pojos.User;
import com.project.service.IProductService;
import com.project.service.IUserService;

@RestController
@CrossOrigin
@RequestMapping("/product")
public class ProductController 
{
	@Autowired(required = true)
	private IProductService pservice;
	
	@Autowired(required = true)
	private IUserService userService;
	
	@PostConstruct
	public void myInit(){
		System.out.println(getClass().getName()+" ...created");
	}
	
	@PostMapping("/imageUpload")
	public ResponseEntity<?> imageUpload(@RequestBody MultipartFile[] fd)
	{
		System.out.println("imageUpload, called");
		//System.out.println(fd);
		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}
	
	/*
	 * @PostMapping("/addProduct") public ResponseEntity<?>
	 * saveOrUpdateProduct(@RequestBody Product p){
	 * System.out.println("ProductController.saveOrUpdateProduct : "+p.getImage());
	 * try { pservice.saveOrUpdateProduct(p); return new
	 * ResponseEntity<String>("SUCCESS", HttpStatus.OK); } catch (RuntimeException
	 * e) { e.printStackTrace(); return new ResponseEntity<String>("FAILURE",
	 * HttpStatus.BAD_REQUEST); } }
	 */
	
	@PostMapping("/addProduct/{vId}")
	public ResponseEntity<?> saveOrUpdateProduct(@RequestBody Product p, @PathVariable int vId)
	{
		User u = userService.getUserById(vId);
		u.addProduct(p);
		System.out.println("saveOrUpdateProduct hello");
		if(userService.registerUser(u))
			return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
		return new ResponseEntity<String>("FAILURE", HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("/addProductA")
	public ResponseEntity<?> saveOrUpdateProductA(@RequestBody Product p)
//												 @RequestBody MultipartFile image)
//												 @RequestParam(value = "gtin", required = false) String gtin, 
//												 @RequestParam(value = "name", required = false) String name) 
//												 @RequestParam String category, 
//												 @RequestParam String material, 
//												 @RequestParam String shape, 
//												 @RequestParam String finish, 
//												 @RequestParam String description, 
//												 @RequestParam String price, 
//												 @RequestParam(value="image", required = false)  MultipartFile image)
	{
		
		if(pservice.saveOrUpdateProduct(p))
			return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
		return new ResponseEntity<String>("FAILURE", HttpStatus.BAD_REQUEST);
		
//		Product p = new Product();
//		if(image != null)
//			System.out.println("in saveOrUpdateProduct : ");//+p1.getName());
//		if(image != null)
//			System.out.println("image obtained...");
//			return new ResponseEntity<String>("MPF SUCCESS", HttpStatus.OK);
		//return new ResponseEntity<String>("MPF FAILURE", HttpStatus.BAD_REQUEST);
//		System.out.println(mpf.toString());
//		p.setName(mpd);
		
		/*
		 * System.out.println("ProductController.saveOrUpdateProduct : "+p.getImage());
		 * try { pservice.saveOrUpdateProduct(p); return new
		 * ResponseEntity<String>("SUCCESS", HttpStatus.OK); } catch (RuntimeException
		 * e) { e.printStackTrace(); return new ResponseEntity<String>("FAILURE",
		 * HttpStatus.BAD_REQUEST); }
		 */		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getProductById(@PathVariable int id){
		System.out.println("product id : "+id);
		try {
			return new ResponseEntity<Product>(pservice.getProductById(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("No such Product found!!!",HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping
	public ResponseEntity<?> getAllProducts(){
		try {
			return new ResponseEntity<List<Product>>(pservice.getAllProducts(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("No Products found!!!",HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/deleteProduct")
	public ResponseEntity<?> deleteProduct(@PathVariable int productId)
	{
		if(pservice.deleteProductById(productId))
			return new ResponseEntity<String>("Product Deleted Successfully!!!", HttpStatus.OK);
		return new ResponseEntity<String>("Failed to Delete the product!!!", HttpStatus.BAD_REQUEST);
	}
}
