import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ProjectService } from '../project.service';
import OrderProduct from '../OrderProduct.model';
import Order from '../Order.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  products:any[];
  userId;
  allProducts:any[];
  product:{"id":null,"gtin":null,"name":null,"category":null,
  "material":null,"shape":null,"series":null,"finish":null,"description":null,
  "price":null, "image":null}
 // order1:{"product":any, "quantity":number};
  order1;
  order = new Order();
  total = 0;  
  x = 0;
  existing;
  mySubscription:any;
  numberOfItems=0;

  orderProduct = new OrderProduct();

  constructor(private router:Router,
              private projectService:ProjectService) { 
    this.allProducts = [{"id":null,"gtin":null,"name":null,"category":null,"material":null,"shape":null,
              "series":null,"finish":null, "image":null ,"description":null,"price":null, "quantity":null}]
  //                      {"id":2,"gtin":7876,"name":"tile4","category":"PORCELAIN","material":"METAL","shape":"PENNY","finish":"TEXTURED","description":"klakldjioroeoj","price":299.0},
  //                      {"id":3,"gtin":23125,"name":"tile333","category":"CERAMIC","material":"TERRAZZO","shape":"MASAIC","finish":"GLOSSY","description":"asjkqruiehuihd","price":599.0}];
  //  this.order1.product = null;
  //  this.order1.quantity = null;
  this.router.routeReuseStrategy.shouldReuseRoute = function () {
    return false;
  };
  this.mySubscription = this.router.events.subscribe((event) => {
    if (event instanceof NavigationEnd) {
      // Trick the Router into believing it's last link wasn't previously loaded
      this.router.navigated = false;
    }
  });
}

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");

    if(this.isActive !='1')
      this.router.navigate(['/login'])
    this.role = localStorage.getItem('role')
    this.userId = localStorage.getItem("user id");
    let pr = localStorage.getItem("products");
    
    if(pr!=null){
      console.log("cart component")
      let p = pr.split(',')
      console.log(p);
      this.numberOfItems = p.length
      console.log("p length :"+p.length);
      this.allProducts.pop()
      p.forEach(element => {
        this.projectService.GetProductById(element).subscribe((result:any)=>{
          console.log("result id : "+result.id)
          this.allProducts.push(result);
            this.allProducts.forEach(item => {
              this.product = item

              this.orderProduct.product_id = item
              this.orderProduct.quantity = 1
              console.log(this.orderProduct)
              // this.order1.product = item
              // this.order1.quantity = 0
             // this.order.push(this.order1)
    this.order.orderProduct.push(this.orderProduct)
              item.quantity = 1;
              item.subTotal = parseInt(item.price);
              this.x = item.subTotal
        //     this.total = this.total + item.subTotal
              console.log("item.subTotal : "+item.subTotal )
      //       this.total = item.subTotal + this.total;
              
            }); 
          this.total = this.total + this.x
          console.log("this.total :"+this.total)
        });
        for(let i=0; i<this.allProducts.length;i++)
        this.total = this.total + this.allProducts[i].price;
      });
    }else{
      window.alert("Your cart is empty!!!")
      this.router.navigate(['/home'])
    }
    console.log(this.total)
  }

  addItem(product)
  {
    product.quantity = product.quantity + 1;
    this.total = this.total - product.subTotal;
    product.subTotal = product.quantity * parseInt(product.price);
    this.total = this.total + product.subTotal;
//    this.total = product.subTotal + this.total;
  }
  delItem(product)
  {
    if(product.quantity>1){
      product.quantity = product.quantity - 1;
      this.total = this.total - product.subTotal;
      product.subTotal = product.quantity * parseInt(product.price);
      this.total = this.total - product.subTotal;
    }else{
      
    }
  }
  GoToHome()
  {
    this.router.navigate(['/home']);
  }
  Delete(pid){
    if(localStorage.getItem("products")!=undefined){

      for(let i=0;i<this.allProducts.length;i++){
        if(pid == this.allProducts[i].id){
  //        window.alert("product to be deleted : "+this.allProducts[i].id)
          delete this.allProducts[i]
          
          console.log(this.allProducts[i])
          this.existing = localStorage.getItem('products');
          console.log(this.existing)
          // If no existing data, create an array
          // Otherwise, convert the localStorage string to an array
              this.existing = this.existing ? this.existing.split(',') : [];
          // Add new data to localStorage Array
   //       if(this.existing.includes(pid.toString()))
          for(let j=0; j<this.existing.length;j++){
            if(pid.toString() == this.existing[j]){
              this.existing.splice(j,1)
              localStorage.setItem('products', this.existing.toString());
            }   
          }
            console.log(localStorage.getItem("products"))
   //         delete this.existing[pid]
    //      else
    //        window.alert("Deleted from cart successfully..")
        }
      }
      this.router.navigate(['/cart'])
    }
    else{
      window.alert("Your cart is empty!!!")
      this.router.navigate(['/home'])
    }
    
  }

  CheckOut(){
    while(this.order.orderProduct.length>0){
      this.order.orderProduct.pop();
    }
      
    console.log(this.order)
    console.log("this.allProducts length : "+this.allProducts.length)
    for(let i=0; i<this.allProducts.length;i++){
      console.log(this.allProducts[i])
      this.orderProduct.product_id = this.allProducts[i]
      console.log(this.orderProduct.product_id)
      this.orderProduct.quantity = this.allProducts[i].quantity
      console.log(this.orderProduct.quantity)
      console.log(this.orderProduct)
      this.order.orderProduct[i] = new OrderProduct();
      console.log(this.order.orderProduct[i])
     this.order.orderProduct[i].product_id = this.orderProduct.product_id
     console.log()
     this.order.orderProduct[i].quantity = this.allProducts[i].quantity
     // this.order.orderProduct.push(this.orderProduct);
      console.log(this.order)
    //  this.order.orderProduct.push(this.allProducts[i]);
    //  this.order.quantity = this.allProducts[i].quantity
   //   console.log(this.orderProduct)
  //    this.order.orderProduct.push
 //     this.order.push(this.allProducts[i],)
 //     console.log("this.product : "+this.product.name)
      console.log(this.order.orderProduct[i])
    }
console.log(this.order)
//if(false){
    this.projectService.CheckOut(this.order, this.userId).subscribe((result:any)=>{
      
      if(result != undefined){
        window.alert("Congratulations your order is placed successfully")
        this.router.navigate(['/cart']);
      }else
        window.alert("failed to add your order...   ")
    });
//}

    localStorage.removeItem("products")
    window.alert("Congratulations your order is placed successfully")
    this.router.navigate(['/home'])

  }
  

  ngOnDestroy()
  {
    if (this.mySubscription) {
      this.mySubscription.unsubscribe();
    }  
  }

}
