import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../project.service';
import { from } from 'rxjs';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  allProducts:any;
  existing;

  constructor(private projectService:ProjectService) { 
    this.allProducts = [{"id":1,"gtin":76789,"name":"tile1","category":"PAVING","material":"TERRAZZO","shape":"MASAIC","finish":"HONED","description":"asjlkdjerui","price":799.0},
    {"id":2,"gtin":7876,"name":"tile4","category":"PORCELAIN","material":"METAL","shape":"PENNY","finish":"TEXTURED","description":"klakldjioroeoj","price":299.0},
    {"id":3,"gtin":23125,"name":"tile333","category":"CERAMIC","material":"TERRAZZO","shape":"MASAIC","finish":"GLOSSY","description":"asjkqruiehuihd","price":599.0}]
    //,"orders":[],"userVendor":null
   // localStorage.removeItem("products")
  }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
    while(this.allProducts.length>0){
      this.allProducts.pop()
    }
    let observableResult = this.projectService.GetAllProducts();
    observableResult.subscribe((result)=>{
      if(result!=undefined)
      this.allProducts = result;
    });
    console.log(this.allProducts)
  }

   AddToCart(Product){
     // Get the existing data
    this.existing = localStorage.getItem('products');

    // If no existing data, create an array
    // Otherwise, convert the localStorage string to an array
        this.existing = this.existing ? this.existing.split(',') : [];
    // Add new data to localStorage Array
    if(!this.existing.includes(Product.id.toString()))
      this.existing.push(Product.id);
    else
      window.alert("Already added to cart...")

    // Save back to localStorage
    localStorage.setItem('products', this.existing.toString());
    // this.cartComponent.products.push(Product)

    let p = localStorage.getItem("products").split(',')
    console.log(p)
    console.log("p length :"+p.length)
    if(p.includes(Product.id.toString()))
      console.log("includes")    
    
   }

   ngOnDestroy()
   {
     console.log("destroy called");
   }  

}
