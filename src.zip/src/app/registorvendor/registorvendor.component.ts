import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registorvendor',
  templateUrl: './registorvendor.component.html',
  styleUrls: ['./registorvendor.component.css']
})
export class RegistorvendorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
