package com.project.pojos;

public enum ProductMaterial {
	CLAY, STONE, METAL, TERRAZZO, QUARTZ
}
