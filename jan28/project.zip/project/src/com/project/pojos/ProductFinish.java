package com.project.pojos;

public enum ProductFinish {
	GLAZED, GLOSSY, MATTE, TEXTURED, HONED, LAPPATO
}
