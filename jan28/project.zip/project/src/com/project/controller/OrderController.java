package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.pojos.Order;
import com.project.service.IOrderService;

@RestController
@CrossOrigin
@RequestMapping("/order")
public class OrderController 
{
	@Autowired
	private IOrderService orderService;
	
	@GetMapping("/{userName}")
	public ResponseEntity<?> getAllOrders(@PathVariable String userName)
	{
		List<Order> o = orderService.getAllOrders(userName);
		if(o != null)
			return new ResponseEntity<List<Order>>(o, HttpStatus.OK);
		return new ResponseEntity<String>("No Order Found", HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/get/{userId}")
	public ResponseEntity<?> getOrderById(@PathVariable int userId)
	{
		List<Order> o = orderService.getOrderById(userId);
		if(o != null)
			return new ResponseEntity<List<Order>>(o, HttpStatus.OK);
		return new ResponseEntity<String>("No Order Found", HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/addOrder/{cId}")
	public ResponseEntity<?> saveOrUpdateOrder(@RequestBody Order o, @PathVariable int cId)
	{
		System.out.println("customer id : "+cId);
		if(o!=null)
			System.out.println("not null...yahooooo");
		System.out.println("hi bheshaj, controller called");
		if(orderService.saveOrUpdateOrder(o, cId)) {
			System.out.println("order added successfully...");
			return new ResponseEntity<String>("SUCCESS!!!", HttpStatus.OK);
		}
		return new ResponseEntity<String>("FAILED!!!", HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("/delete/{orderId}")
	public ResponseEntity<?> deleteOrder(@PathVariable int orderId)
	{
		if(orderService.deleteOrder(orderId))
			return new ResponseEntity<String>("Deleted successfully!!!", HttpStatus.OK);
		return new ResponseEntity<String>("Failed to delete your order!!!", HttpStatus.NOT_FOUND);
	}
}
