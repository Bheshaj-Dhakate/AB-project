package com.project.dao;

import java.util.List;

import com.project.pojos.User;

public interface IUserDao 
{
	User validateUser(User u);
	Boolean registerUser(User u);
	User getPassword(String username);
	User getUserById(int uId);
	Boolean changePassword(User u);
	List<User> getAllVendors();
}
