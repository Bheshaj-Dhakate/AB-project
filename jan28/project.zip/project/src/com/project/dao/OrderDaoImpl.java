package com.project.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.pojos.Order;
import com.project.pojos.OrderProduct;
import com.project.pojos.User;

@Repository
@Transactional
public class OrderDaoImpl implements IOrderDao 
{
	@Autowired
	private SessionFactory sf;
	
	@Override
	public List<Order> getAllOrders(String userName) {
//		String jpql = "select o from Order o left outer"
//		sf.getCurrentSession()
		return null;
	}

	@Override
	public List<Order> getOrderById(int userId) {
		try {
			
			User u = sf.getCurrentSession().get(User.class, userId);
			List<Order> ol = u.getOrders(); 
			String jpql = "select distinct o from Order o join fetch o.orderProduct op where o.user =:user";
			ol = sf.getCurrentSession().createQuery(jpql, Order.class).setParameter("user", u).getResultList();
			System.out.println(u);
			//System.out.println(ol);
			return ol;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Boolean saveOrUpdateOrder(Order o, int cId) {
		System.out.println("hi bheshaj, dao called");
		try {
			User u  =sf.getCurrentSession().get(User.class, cId);
			u.addOrder(o);
			List<OrderProduct> ops = o.getOrderProduct();
			for (OrderProduct orderProduct : ops) {
				orderProduct.setOrder_id(o);
				System.out.println("hello");
			}
			System.out.println("hi bheshaj");
			sf.getCurrentSession().merge(u);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public Boolean deleteOrder(int orderId){
		try {
			Order o = sf.getCurrentSession().get(Order.class, orderId);
			sf.getCurrentSession().delete(o);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return false;
	}


	
}
