package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.dao.IOrderDao;
import com.project.pojos.Order;

@Service
@Transactional
public class OrderServiceImpl implements IOrderService {
	@Autowired
	private IOrderDao orderDao;
	
	@Override
	public List<Order> getAllOrders(String userName) {
		return orderDao.getAllOrders(userName);
	}

	@Override
	public List<Order> getOrderById(int userId) {
		return orderDao.getOrderById(userId);
	}

	@Override
	public Boolean saveOrUpdateOrder(Order o, int cId) {
		return orderDao.saveOrUpdateOrder(o, cId);
	}

	@Override
	public Boolean deleteOrder(int orderId) {
		return orderDao.deleteOrder(orderId);
	}



}
