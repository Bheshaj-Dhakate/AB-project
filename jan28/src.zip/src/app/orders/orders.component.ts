import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ProjectService } from '../project.service';
import Order from '../Order.model';
import OrderProduct from '../OrderProduct.model';


@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  userName;
  userId;
  order:Order[];
  products:any[];
  allProducts:any[];
  product:{"id":null,"gtin":null,"name":null,"category":null,
  "material":null,"shape":null,"series":null,"finish":null,"description":null,
  "price":null, "image":null}
 // order1:{"product":any, "quantity":number};
  order1;
  total = 0;  
  x = 0;
  existing;
  mySubscription:any;
  numberOfItems=0;
  nobita:boolean =true;

  orderProduct = new OrderProduct();
  
  constructor(private router:Router,
              private projectService:ProjectService,
              private route:ActivatedRoute) {
    
    this.allProducts = [{"id":null,"gtin":null,"name":null,"category":null,"material":null,"shape":null,
    "series":null,"finish":null, "image":null ,"description":null,"price":null, "quantity":null}]
    //                      {"id":2,"gtin":7876,"name":"tile4","category":"PORCELAIN","material":"METAL","shape":"PENNY","finish":"TEXTURED","description":"klakldjioroeoj","price":299.0},
    //                      {"id":3,"gtin":23125,"name":"tile333","category":"CERAMIC","material":"TERRAZZO","shape":"MASAIC","finish":"GLOSSY","description":"asjkqruiehuihd","price":599.0}];
    //  this.order1.product = null;
    //  this.order1.quantity = null;
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false; 
    };
    this.mySubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Trick the Router into believing it's last link wasn't previously loaded
        this.router.navigated = false;
      }
    });
  }

  

  ngOnInit() {    
    this.userName = localStorage.getItem("username");
    this.welcomeMessage = "Welcome, "+ this.userName;
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')    

    if(this.isActive == undefined && this.role !='CUSTOMER' && this.nobita){
      this.router.navigate(['/login'])
    }else{
      this.userId = localStorage.getItem("user id")
      this.projectService.GetAllOrders(this.userId).subscribe((result:any)=>{
        
        if(result != undefined){
          this.allProducts.pop()
          this.order = result;
          console.log(this.order)
          console.log(this.order.length)
          
          /*
          for(let i=0;i<this.order.length;i++){
            this.allProducts.push(this.order[i].orderProduct)
            console.log(this.allProducts)
            for(let j=0; j<this.order[i].orderProduct.length;j++)
            {
              console.log(this.order[i].orderProduct[j].product_id)
              this.allProducts.push(this.order[i].orderProduct[i].product_id)
              console.log(this.order[i].orderProduct[j].quantity)
              this.allProducts[i].quantity = this.order[i].quantity;
            }
            
       //     this.allProducts.push(this.order[i].orderProduct[i].product_id)
       //     this.allProducts[i].quantity = this.order[i].quantity;
            //this.orderProduct[i] = this.order[i].orderProduct;
          }
          */

        }
        console.log(this.allProducts)
      });
    }

    // this.route.paramMap.subscribe((parameter:any)=>{
    //   let userEmail = parameter.get("userEmail");
    // });
  }

  LoginFirst()
  {
    this.router.navigate(["/login"]);
  }



  ngOnDestroy()
  {
    if (this.mySubscription) {
      this.mySubscription.unsubscribe();
    }  
  }
}
