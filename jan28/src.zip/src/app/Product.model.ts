
export default class Product{

    public id:number;
    public gtin:number;
    public name:string;
    public category:string;
    public material:string;
    public shape:string;
    public finish:string;
    public series:string;
    public image:any;
    public description:string;
    public price:number;

    constructor(){}
}