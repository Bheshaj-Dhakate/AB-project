import OrderProduct from './OrderProduct.model';

export default class Order{

    public id:number;
    public quantity:number;
    public orderTime:any;
    public user:any;
    public orderProduct:OrderProduct[]=[];

    constructor(){} 
}