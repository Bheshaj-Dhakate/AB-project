import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-registorvendor',
  templateUrl: './registorvendor.component.html',
  styleUrls: ['./registorvendor.component.css']
})
export class RegistorvendorComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  message;
  constructor(private router:Router, private projectService:ProjectService) { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
  }

    
  async Register(formdata)
  {
    let user = formdata.form.value;
    user.role = "VENDOR"
    console.log("vendor role : "+user.role)
    if(user.name != undefined && user.email != undefined && user.password != undefined 
      && user.address != undefined && user.mobileNo != undefined && user.role != undefined 
      && user.tan != undefined && user.bankAccount != undefined && user.gstNo != undefined
      && user.regNo != undefined){
       
          let observableResult = await this.projectService.Register(user);
          console.log(observableResult);
          observableResult.subscribe((result : any)=>{
              if(result !== undefined)
                window.alert("Vendor registered successfully!");
              else
                window.alert("Vendor registration failed!");
          });
    }else{
        window.alert("Missing field...")
        this.router.navigate(['/registorvendor']);
    }
    this.router.navigate(['/login']) 
  }

  GoToHome(){
    this.router.navigate(['/home']);
  }
}
