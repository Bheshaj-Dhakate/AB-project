import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../project.service';
import { ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  product={
    gtin:"00007777",
	  name:"nobita",
	  category:"PORCELAIN",
	  material:"CLAY",
	  shape:"MASAIC",
    finish:"GLAZED",
    series:"CARVING",
	  image:File=null,
	  description:"this is porcelain tile made from clay",
    price:899
  };
  oldProduct;
  regNo:any[];
  vendorFound;
  vId;
  message;
  welcomeMessage:string;
  isActive:string;
  role;
  vendors:any[];
    //FILE UPLOADING
    fileData: File = null;
    previewUrl:any = null;
    fileUploadProgress: string = null;
    uploadedFilePath: string = null;

  constructor(private route:ActivatedRoute,
              private router:Router,
              private projectService:ProjectService) 
  { }

  ngOnInit() {
    let username = localStorage.getItem("username");
    this.welcomeMessage = "Welcome, "+ username;
    this.projectService.GetVendorRegNo(username).subscribe((result:any)=>{
        this.regNo = result.regNo;
    });
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
    if(this.role == "ADMIN" || this.role == "VENDOR")
    {
      this.route.paramMap.subscribe((parameter)=>{
        let productId = parameter.get("id");
        console.log("AddproductComponent.ngOnInit() : "+productId);
        if(productId!=null){
          console.log("test : bheshaj")
          let observableResult = this.projectService.GetProductById(productId);
          observableResult.subscribe((result:any)=>{
            this.oldProduct = result;
          });
        }
      });
      
    }
    this.product= {
      gtin:"00007777",
      name:"nobita",
      category:"PORCELAIN",
      material:"CLAY",
      shape:"MASAIC",
      finish:"GLAZED",
      series:"CARVING",
      image:File=null,
      description:"this is porcelain tile made from clay",
      price:899
    };
  }

  fileProgress(fileInput: any) {
    console.log("fileProgress")
    console.log("fileInput: "+fileInput);
    this.fileData = <File>fileInput.target.files[0];
    this.product.image = this.fileData
    console.log(this.fileData)
    console.log("file name : "+this.fileData.name)
    console.log("file size : "+this.fileData.size)
    this.preview();
  }
  preview() {
    // Show preview 
    console.log("preview()")
    var mimeType = this.fileData.type;
    console.log("mimeType : "+ mimeType)
    if (mimeType.match(/image\/*/) == null) {
      console.log("if=>true")
      return;
    }
 
    var reader = new FileReader();      
    reader.readAsDataURL(this.fileData); 
    reader.onload = (_event) => { 
      this.previewUrl = reader.result; 
      //console.log("this.previewUrl "+ this.previewUrl)
    }
  }
  onSubmit() {
    console.log("onSubmit()")
    const formData = new FormData();
    formData.append('file', this.fileData);
    console.log(formData)
  }  

  SaveOrUpdateProduct(productForm){
    if(localStorage.getItem("role") == 'ADMIN'){
      console.log("role : ADMIN")
      this.projectService.GerAllVendors().subscribe((result:any)=>{
        result.forEach(element => {
          console.log(element.regNo)
          if(this.regNo == element.regNo){
            this.vId = element.id
            console.log("vendor id : "+element.id)
            console.log("if : vId : "+this.vId)
            let product = productForm.form.value;
            if(product.name != undefined &&
              product.gtin != undefined &&
              product.category != undefined &&
              product.material != undefined &&
              product.shape != undefined &&
              product.finish != undefined &&
              product.series != undefined &&
              product.description != undefined &&
              product.price != undefined &&
              this.vId != undefined ){
                  let observableResult = this.projectService.SaveOrUpdateProduct(product, this.vId);
                  observableResult.subscribe((result:any)=>{
                      window.alert("PRODUCT ADDED SUCCESSFULLY!");
                  });       
            }else
                window.alert("Missing field...")
                this.router.navigate(['/addProduct'])
          }
        //  this.vendors.push(element.regNo);
        });
      });

      
    }else{
      this.vId = localStorage.getItem("user id")
      console.log("else : vId : "+this.vId)
      let product = productForm.form.value;
      if(product.name != undefined &&
        product.gtin != undefined &&
        product.category != undefined &&
        product.material != undefined &&
        product.shape != undefined &&
        product.finish != undefined &&
        product.series != undefined &&
        product.description != undefined &&
        product.price != undefined &&
        this.vId != undefined ){
            let observableResult = this.projectService.SaveOrUpdateProduct(product, this.vId);
            observableResult.subscribe((result:any)=>{
                window.alert("PRODUCT ADDED SUCCESSFULLY!");
            });       
      }else
          window.alert("Missing field...")
      this.router.navigate(['/addProduct'])
    
    }
}
}

  /*
  SaveOrUpdateProduct1(productForm){
    if(this.oldProduct !== undefined){
      console.log("if :SaveOrUpdateProduct");
      let observableResult = this.projectService.SaveOrUpdateProduct(this.product);
      observableResult.subscribe((result:any)=>{
        if( result == "SUCCESS"){
          window.alert("PRODUCT DETAILS UPDATED SUCCESSFULLY!");
          this.router.navigate(['/product']);
        }
        else{
          window.alert("FAILED TO UPDATE PRODUCT DETAILS!");
          this.router.navigate(['/addProduct']);
        }
      });
    }else{
      //this.product.image.append('image', this.fileData)
      console.log("else : ")
      const formData = new FormData();
      formData.append('name', this.product.name);
      formData.append('gtin', this.product.gtin);
      formData.append('category', this.product.category);
      formData.append('material', this.product.material);
      formData.append('shape', this.product.shape);
      formData.append('finish', this.product.finish);
      formData.append('image', this.product.image);
      formData.append('description', this.product.description);
      formData.append('price', this.product.price.toString());

      console.log(this.product.name)
      console.log(this.product.gtin)
      console.log(this.product.category)
      console.log(this.product.material)
      console.log(this.product.shape)
      console.log(this.product.finish)
      console.log(this.product.description)
      console.log(this.product.price)
      console.log(this.product.image.name)

//      formData.append('file', this.fileData);
//      console.log("l = "+Object.keys(formData.get('file')).length)

      console.log("else :SaveOrUpdateProduct");
//      let product = productForm.form.value;
//      console.log("product.name : "+product.name)
//      product.image = this.fileData
      console.log("product : "+this.product.name)
      // console.log("image : "+product.image.name)
      // console.log("length : "+product.image.size)
      this.product.image = null
      productForm.image = null
//      let observableResult = this.projectService.SaveOrUpdateProduct(formData);
//      let observableResult = this.projectService.SaveOrUpdateProduct(this.product);
      let observableResult = this.projectService.SaveOrUpdateProduct(productForm);
      observableResult.subscribe((result:any)=>{
          window.alert("PRODUCT ADDED SUCCESSFULLY!");
          this.router.navigate(['/product']);
          }, err =>{
            console.log(err)
            window.alert("FAILED TO ADD PRODUCT!");
            this.router.navigate(['/addProduct']);
      }); 

    }
  }
*/

/*

//      formData.append('file', this.fileData);
//      console.log("l = "+Object.keys(formData.get('file')).length)

      console.log("else :SaveOrUpdateProduct");
//      let product = productForm.form.value;
//      console.log("product.name : "+product.name)
//      product.image = this.fileData
      console.log("product : "+this.product.name)
      // console.log("image : "+product.image.name)
      // console.log("length : "+product.image.size)
      this.product.image = this.fileData
//      let observableResult = this.projectService.SaveOrUpdateProduct(formData);
      let observableResult = this.projectService.SaveOrUpdateProduct(this.product);
      observableResult.subscribe((result:any)=>{
          window.alert("PRODUCT ADDED SUCCESSFULLY!");
          this.router.navigate(['/product']);
          }, err =>{
            console.log(err)
            window.alert("FAILED TO ADD PRODUCT!");
            this.router.navigate(['/addProduct']);
      });

*/
