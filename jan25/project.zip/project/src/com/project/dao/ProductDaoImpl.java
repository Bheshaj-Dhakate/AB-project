package com.project.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.pojos.Product;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {
	
	@Autowired
	private SessionFactory sf;

	@Override
	public Boolean saveOrUpdateProduct(Product p) {
		try {
			sf.getCurrentSession().saveOrUpdate(p);
			return true;
		} catch (RuntimeException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Product getProductById(int id) {
		try {
			return sf.getCurrentSession().get(Product.class, id);
		} catch (RuntimeException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		try {
			String jpql = "select p from Product p left outer join fetch p.orderProduct o";
			List<Product> allProducts = sf.getCurrentSession().createQuery(jpql, Product.class).getResultList();
			//jpql = "select p form Product p join fetch p.userVendor v";
			//jpql = "select v from User v join fetch v.products p";
			//allProducts = sf.getCurrentSession().createQuery(jpql, Product.class).getResultList();
			return allProducts;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Boolean deleteProductById(int productId) {
		try {
			sf.getCurrentSession().delete(this.getProductById(productId));
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return false;
	}

	
}
