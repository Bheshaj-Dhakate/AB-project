package com.project.dao;

import com.project.pojos.Order;
import com.project.pojos.OrderProduct;

public interface IOrderDao {
	Order getOrderById(int orderId);
	Boolean saveOrUpdateOrder(Order o, int cId);
	Boolean deleteOrder(int orderId);
}
