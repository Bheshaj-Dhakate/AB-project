package com.project.dao;

import java.util.List;

import com.project.pojos.Product;

public interface IProductDao {
	Boolean saveOrUpdateProduct(Product p);
	Product getProductById(int id);
	List<Product> getAllProducts();
 	Boolean deleteProductById(int productId);
}
