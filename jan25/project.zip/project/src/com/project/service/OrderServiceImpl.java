package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.dao.IOrderDao;
import com.project.pojos.Order;
import com.project.pojos.OrderProduct;

@Service
@Transactional
public class OrderServiceImpl implements IOrderService {
	@Autowired
	private IOrderDao orderDao;

	@Override
	public Order getOrderById(int orderId) {
		return orderDao.getOrderById(orderId);
	}

	@Override
	public Boolean saveOrUpdateOrder(Order o, int cId) {
		return orderDao.saveOrUpdateOrder(o, cId);
	}

	@Override
	public Boolean deleteOrder(int orderId) {
		return orderDao.deleteOrder(orderId);
	}

}
