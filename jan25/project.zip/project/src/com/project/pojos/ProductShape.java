package com.project.pojos;

public enum ProductShape {
	PENNY, MASAIC, SQUARE, SUBWAY, PLANK
}
