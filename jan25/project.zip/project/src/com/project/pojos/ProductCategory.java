package com.project.pojos;

public enum ProductCategory 
{
	PORCELAIN, PAVING, CERAMIC, ETERNITY
}
