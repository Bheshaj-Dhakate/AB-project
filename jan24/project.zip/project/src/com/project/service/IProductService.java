package com.project.service;

import java.util.List;

import com.project.pojos.Product;

public interface IProductService {
	Boolean saveOrUpdateProduct(Product p);
	Product getProductById(int id);
	List<Product> getAllProducts();
	Boolean deleteProductById(int productId);
}
