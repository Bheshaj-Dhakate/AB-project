import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
    
  welcomeMessage:string;
  isActive:string;
  role:string;
 
constructor(private router:Router) { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
  }

  Register(){
    this.router.navigate(['/contactus']);
  }
}
