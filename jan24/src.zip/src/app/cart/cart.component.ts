import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;
  products:any[];
  userId;
  order:object
  allProducts:any[];
  total = 0;  
  x = 0;
  existing;
  mySubscription:any;

  constructor(private router:Router,
              private projectService:ProjectService) { 
    this.allProducts = [{"id":null,"gtin":null,"name":null,"category":null,"material":null,"shape":null,"finish":null,"description":null,"price":null}]
  //                      {"id":2,"gtin":7876,"name":"tile4","category":"PORCELAIN","material":"METAL","shape":"PENNY","finish":"TEXTURED","description":"klakldjioroeoj","price":299.0},
  //                      {"id":3,"gtin":23125,"name":"tile333","category":"CERAMIC","material":"TERRAZZO","shape":"MASAIC","finish":"GLOSSY","description":"asjkqruiehuihd","price":599.0}];
                
  this.router.routeReuseStrategy.shouldReuseRoute = function () {
    return false;
  };
  this.mySubscription = this.router.events.subscribe((event) => {
    if (event instanceof NavigationEnd) {
      // Trick the Router into believing it's last link wasn't previously loaded
      this.router.navigated = false;
    }
  });
}

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    if(this.isActive !='1')
      this.router.navigate(['/login'])
    this.role = localStorage.getItem('role')
    this.userId = localStorage.getItem("user id");
    let pr = localStorage.getItem("products");
    
    if(pr!=null){
      console.log("cart component")
      let p = pr.split(',')
      console.log(p);
      console.log("p length :"+p.length);
      this.allProducts.pop()
      p.forEach(element => {
        this.projectService.GetProductById(element).subscribe((result:any)=>{
          this.allProducts.push(result);
            this.allProducts.forEach(item => {
              item.units = 1;
              item.subTotal = parseInt(item.price);
              this.x = item.subTotal
        //     this.total = this.total + item.subTotal
              console.log("item.subTotal : "+item.subTotal )
      //       this.total = item.subTotal + this.total;
              
            });
          this.total = this.total + this.x
          console.log("this.total :"+this.total)
        });
        for(let i=0; i<this.allProducts.length;i++)
        this.total = this.total + this.allProducts[i].price;
      });
    }else{
      window.alert("Your cart is empty!!!")
      this.router.navigate(['/home'])
    }
    console.log(this.total)
  }

  addItem(product)
  {
    product.units = product.units + 1;
    this.total = this.total - product.subTotal;
    product.subTotal = product.units * parseInt(product.price);
    this.total = this.total + product.subTotal;
//    this.total = product.subTotal + this.total;
  }
  delItem(product)
  {
    if(product.units>1){
      product.units = product.units - 1;
      this.total = this.total - product.subTotal;
      product.subTotal = product.units * parseInt(product.price);
      this.total = this.total - product.subTotal;
    }else{
      
    }
  }
  GoToHome()
  {
    this.router.navigate(['/home']);
  }
  Delete(pid){
    if(localStorage.getItem("products")!=undefined){

      for(let i=0;i<this.allProducts.length;i++){
        if(pid == this.allProducts[i].id){
  //        window.alert("product to be deleted : "+this.allProducts[i].id)
          delete this.allProducts[i]
          
          console.log(this.allProducts[i])
          this.existing = localStorage.getItem('products');
          console.log(this.existing)
          // If no existing data, create an array
          // Otherwise, convert the localStorage string to an array
              this.existing = this.existing ? this.existing.split(',') : [];
          // Add new data to localStorage Array
   //       if(this.existing.includes(pid.toString()))
          for(let j=0; j<this.existing.length;j++){
            if(pid.toString() == this.existing[j]){
              this.existing.splice(j,1)
              localStorage.setItem('products', this.existing.toString());
            }   
          }
            console.log(localStorage.getItem("products"))
   //         delete this.existing[pid]
    //      else
    //        window.alert("Deleted from cart successfully..")
        }
      }
      this.router.navigate(['/cart'])
    }
    else{
      window.alert("Your cart is empty!!!")
      this.router.navigate(['/home'])
    }
    
  }

  CheckOut(){
    window.alert("Congratulations your order is placed successfully")
    this.router.navigate(['/checkout']);
  }
  

  ngOnDestroy()
  {
    if (this.mySubscription) {
      this.mySubscription.unsubscribe();
    }  
  }

}
