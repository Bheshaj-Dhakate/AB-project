import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  welcomeMessage:string;
  isActive:string;
  role:string;

  constructor() { }

  ngOnInit() {
    this.welcomeMessage = "Welcome, "+localStorage.getItem("username");
    this.isActive = localStorage.getItem("isActive");
    this.role = localStorage.getItem('role')
  }

}
